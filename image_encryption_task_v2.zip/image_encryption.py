from PIL import Image
import numpy as np

def encrypt_image(image_path, key):
    img = Image.open(image_path)
    img = img.convert("RGB")
    data = np.array(img)
    encrypted_data = (data + key) % 256
    encrypted_img = Image.fromarray(encrypted_data.astype('uint8'))
    encrypted_img.save("encrypted_image.png")
    print("Image encrypted and saved as 'encrypted_image.png'")

def decrypt_image(image_path, key):
    img = Image.open(image_path)
    img = img.convert("RGB")
    data = np.array(img)
    decrypted_data = (data - key) % 256
    decrypted_img = Image.fromarray(decrypted_data.astype('uint8'))
    decrypted_img.save("decrypted_image.png")
    print("Image decrypted and saved as 'decrypted_image.png'")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Encrypt or Decrypt an image using pixel manipulation")
    parser.add_argument("operation", choices=["encrypt", "decrypt"], help="Choose the operation")
    parser.add_argument("image_path", help="Path to the image")
    parser.add_argument("key", type=int, help="Encryption/Decryption key (integer)")
    args = parser.parse_args()

    if args.operation == "encrypt":
        encrypt_image(args.image_path, args.key)
    else:
        decrypt_image(args.image_path, args.key)
