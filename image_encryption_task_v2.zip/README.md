# Task-02: Pixel Manipulation for Image Encryption

## Description
This is a simple Python tool for encrypting and decrypting images by manipulating pixel values.

## Requirements
- Python 3.x
- Pillow
- NumPy

Install dependencies using:
```
pip install pillow numpy
```

## Usage

### Encrypt an image:
```
python image_encryption.py encrypt input_image.png 50
```

### Decrypt an image:
```
python image_encryption.py decrypt encrypted_image.png 50
```

The `key` must be the same number used for encryption and decryption.
