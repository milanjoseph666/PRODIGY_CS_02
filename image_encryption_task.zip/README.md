# Image Pixel Manipulation for Encryption

This Python program encrypts and decrypts images by applying pixel-level arithmetic operations using a key.

## Requirements
- Python 3.x
- Pillow
- NumPy

## Installation
```
pip install pillow numpy
```

## Usage
```
python image_encryption.py
```

You will be prompted to enter:
- Mode: encrypt or decrypt
- Input image path (e.g., input.jpg)
- Output image path (e.g., output.jpg)
- Key (an integer used for pixel shift)

## Example
```
Enter mode (encrypt/decrypt): encrypt
Enter input image path: original.png
Enter output image path: encrypted.png
Enter encryption key (integer): 25
```

Use the same key to decrypt.